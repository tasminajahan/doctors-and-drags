-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 24, 2021 at 09:33 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_doctoranddrags`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `admin_id` int(10) UNSIGNED NOT NULL,
  `admin_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admi_email_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_password_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0,
  `doctor_id` int(11) DEFAULT NULL,
  `assistant_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`admin_id`, `admin_name`, `admi_email_id`, `admin_password_id`, `status`, `doctor_id`, `assistant_id`) VALUES
(1, 'Rasel', 'rasel@gmail.com', '202cb962ac59075b964b07152d234b70', 0, NULL, 0),
(3, 'Ajijul Islam', 'ajijul@gmail.com', '123', 2, 3, 0),
(5, 'Test', 'test@gmail.com', '202cb962ac59075b964b07152d234b70', 4, 1, 3),
(6, 'Anika Jaman Malika', 'anika@gmail.com', '202cb962ac59075b964b07152d234b70', 1, 23, NULL),
(7, 'Johirul Islam Juwel', 'j@gmail.com', '202cb962ac59075b964b07152d234b70', 1, 25, NULL),
(8, 'Galib Ifthekar Rahath', 'gir@gmail.com', '202cb962ac59075b964b07152d234b70', 1, 26, NULL),
(9, 'Suchi', 'suchi@gmail.com', '202cb962ac59075b964b07152d234b70', 3, 26, 5);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_assistant`
--

CREATE TABLE `tbl_assistant` (
  `assistant_id` int(11) NOT NULL,
  `doctor_name` text NOT NULL,
  `doctor_type` int(11) NOT NULL,
  `assistant_name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_assistant`
--

INSERT INTO `tbl_assistant` (`assistant_id`, `doctor_name`, `doctor_type`, `assistant_name`) VALUES
(2, 'Johirul Islam Juwelgfgf', 1, 'Siam Haque'),
(3, 'Johirul Islam Juwelgfgf', 1, 'Test'),
(4, 'Johirul Islam Juwelgfgf', 1, 'TestTest'),
(5, 'Galib Ifthekar Rahath', 26, 'Suchi');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_doctor`
--

CREATE TABLE `tbl_doctor` (
  `doctor_id` int(11) NOT NULL,
  `doctor_name` text NOT NULL,
  `doctor_type` int(11) NOT NULL,
  `admin_status` tinyint(4) NOT NULL DEFAULT 0,
  `img` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_doctor`
--

INSERT INTO `tbl_doctor` (`doctor_id`, `doctor_name`, `doctor_type`, `admin_status`, `img`) VALUES
(23, 'Anika Jaman Malika', 2, 1, 'img/1613876785.jpg'),
(24, 'NImmi Chowdhury', 3, 0, 'img/1613877636.jpg'),
(25, 'Johirul Islam Juwel', 13, 1, 'img/1613877656.jpg'),
(26, 'Galib Ifthekar Rahath', 13, 1, 'img/1613877680.jpg'),
(27, 'Mashkur Taki Talha', 5, 0, 'img/1613877702.jpg'),
(28, 'Bodrul Islam Naiem', 13, 0, 'img/1613877735.jpg'),
(29, 'Modirima Saha', 15, 0, 'img/1613998504.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_doctor_schedule`
--

CREATE TABLE `tbl_doctor_schedule` (
  `doctor_name` text NOT NULL,
  `doctor_type` int(11) NOT NULL,
  `moorning` text DEFAULT NULL,
  `afternoon` text DEFAULT NULL,
  `moorning_place` text DEFAULT NULL,
  `Evening` text DEFAULT NULL,
  `night` text DEFAULT NULL,
  `afternoon_place` text DEFAULT NULL,
  `night_plcae` text DEFAULT NULL,
  `evening_plcae` text DEFAULT NULL,
  `id` int(11) NOT NULL,
  `doctor_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_doctor_schedule`
--

INSERT INTO `tbl_doctor_schedule` (`doctor_name`, `doctor_type`, `moorning`, `afternoon`, `moorning_place`, `Evening`, `night`, `afternoon_place`, `night_plcae`, `evening_plcae`, `id`, `doctor_id`) VALUES
('Galib Ifthekar Rahath', 13, '8-11', '2-3', 'AmbarKhaka', '4-5', '7-8', 'Chowhatta', 'Rikabibazar', 'Zindabazar', 3, 26),
('Johirul Islam Juwel', 13, '8-11', '2-3', 'AmbarKhaka', '4-5', '7-8', 'Chowhatta', 'Rikabibazar', 'Zindabazar', 4, 25);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_doctor_type`
--

CREATE TABLE `tbl_doctor_type` (
  `type_id` int(11) NOT NULL,
  `type_name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_doctor_type`
--

INSERT INTO `tbl_doctor_type` (`type_id`, `type_name`) VALUES
(2, 'Anesthesiologists'),
(3, 'Cardiologists'),
(4, 'Colon and Rectal Surgeons'),
(5, 'Critical Care Medicine Specialists'),
(7, 'Endocrinologists'),
(8, 'Emergency Medicine Specialists'),
(9, 'Family Physicians'),
(10, 'Gastroenterologists'),
(11, 'Geriatric Medicine Specialists'),
(12, 'Nephrologists'),
(13, 'Neurologists'),
(14, 'Obstetricians and Gynecologists'),
(15, 'Oncologists'),
(16, 'Ophthalmologists');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_message`
--

CREATE TABLE `tbl_message` (
  `ms_id` int(11) NOT NULL,
  `message_body` text NOT NULL,
  `messerger_name` text NOT NULL,
  `messager_email` text NOT NULL,
  `message_subject` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_message`
--

INSERT INTO `tbl_message` (`ms_id`, `message_body`, `messerger_name`, `messager_email`, `message_subject`) VALUES
(3, 'Ki Khobor Reply daw na kno', 'Nusratth Jahan Orpa', 'nusrath@gmail.com', 'Love'),
(4, 'I need a job', 'Irfan Pathan', 'pf@gmail.com', 'Job'),
(5, 'Hi I am Zahir Khan From India', 'Zahir', 'zk@gmail.com', 'Greetings'),
(6, 'Can You give me your mobaile number plz', 'Ashraful', 'ash@gmail.com', 'Contract'),
(7, 'Hi Lima', 'Zahir', 'limon@gmail.com', 'Greetings'),
(8, 'ssssssss', 's', 's@gmail.com', 'Contract'),
(9, 'fdfdfd', 'Irfan Pathan', 's@gmail.com', 'dfdfd');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_prscription`
--

CREATE TABLE `tbl_prscription` (
  `patient_id` int(11) NOT NULL,
  `doctor_name` text NOT NULL,
  `doctor_id` int(11) NOT NULL,
  `doctor_designation` text NOT NULL,
  `patient_name` text NOT NULL,
  `patient_age` text NOT NULL,
  `patient_gender` text NOT NULL,
  `prescription_body` text NOT NULL,
  `payment_status` tinyint(4) DEFAULT 0,
  `created_at` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_prscription`
--

INSERT INTO `tbl_prscription` (`patient_id`, `doctor_name`, `doctor_id`, `doctor_designation`, `patient_name`, `patient_age`, `patient_gender`, `prescription_body`, `payment_status`, `created_at`) VALUES
(1, 'Johirul Islam Juwelgfgf', 0, 'Obstetricians and Gynecologists', 'Tuntu Bilay', '1', 'Male', '-Napa\r\n-Peracitamol', 1, '2021-02-19'),
(2, 'Johirul Islam Juwelgfgf', 0, 'Obstetricians and Gynecologists', 'Trum', '89', 'Male', '-Do not make Diet\r\n- No drag need for you', NULL, '2021-02-19'),
(3, 'Johirul Islam Juwelgfgf', 0, 'Obstetricians and Gynecologists', 'Hussy Bangaiyee', '34', 'Female', 'aroma problem', 0, '2021-02-20'),
(4, 'Galib Ifthekar Rahath', 0, 'Neurologists', 'Taher', '45', 'Male', 'fjdkfkdjfkdjfbvdkgdkfjd', 1, '2021-02-22'),
(5, 'Johirul Islam Juwel', 25, 'Neurologists', 'Test', '44', 'Female', '44444444444tegdcbcfgd', 0, '2021-02-24');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_ticket`
--

CREATE TABLE `tbl_ticket` (
  `ticket_id` int(11) NOT NULL,
  `doctor_id` int(11) NOT NULL,
  `doctor_name` text NOT NULL,
  `Patient_name` text NOT NULL,
  `time` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_ticket`
--

INSERT INTO `tbl_ticket` (`ticket_id`, `doctor_id`, `doctor_name`, `Patient_name`, `time`) VALUES
(1, 24, 'NImmi Chowdhury', 'Sainur', 2),
(2, 24, 'NImmi Chowdhury', 'Sainur', 2),
(3, 25, 'Johirul Islam Juwel', 'Ahmed', 2),
(4, 25, 'Johirul Islam Juwel', 'Saimum', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `tbl_assistant`
--
ALTER TABLE `tbl_assistant`
  ADD PRIMARY KEY (`assistant_id`);

--
-- Indexes for table `tbl_doctor`
--
ALTER TABLE `tbl_doctor`
  ADD PRIMARY KEY (`doctor_id`);

--
-- Indexes for table `tbl_doctor_schedule`
--
ALTER TABLE `tbl_doctor_schedule`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_doctor_type`
--
ALTER TABLE `tbl_doctor_type`
  ADD PRIMARY KEY (`type_id`);

--
-- Indexes for table `tbl_message`
--
ALTER TABLE `tbl_message`
  ADD PRIMARY KEY (`ms_id`);

--
-- Indexes for table `tbl_prscription`
--
ALTER TABLE `tbl_prscription`
  ADD PRIMARY KEY (`patient_id`);

--
-- Indexes for table `tbl_ticket`
--
ALTER TABLE `tbl_ticket`
  ADD PRIMARY KEY (`ticket_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `admin_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tbl_assistant`
--
ALTER TABLE `tbl_assistant`
  MODIFY `assistant_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_doctor`
--
ALTER TABLE `tbl_doctor`
  MODIFY `doctor_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `tbl_doctor_schedule`
--
ALTER TABLE `tbl_doctor_schedule`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_doctor_type`
--
ALTER TABLE `tbl_doctor_type`
  MODIFY `type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tbl_message`
--
ALTER TABLE `tbl_message`
  MODIFY `ms_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_prscription`
--
ALTER TABLE `tbl_prscription`
  MODIFY `patient_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_ticket`
--
ALTER TABLE `tbl_ticket`
  MODIFY `ticket_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
