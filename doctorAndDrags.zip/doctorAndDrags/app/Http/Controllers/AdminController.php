<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Redirect;

use Illuminate\Http\Request;
use Session;
use DB;
use PDF;
session_start();


class AdminController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
     public function login()
    {
       return view('admin.login');
    }
    

     public function admin_login_check(Request $request)
    {
         $admin_email_address=$request->admi_email_id;
         $admin_password=md5($request->admin_password_id);
          $users = DB::table('tbl_admin')
                 ->where('admi_email_id', $admin_email_address)
                 ->where('admin_password_id', $admin_password)
                 ->first();
                
      if($users){
           if (is_null($users->doctor_id) ) {
              Session::put('admin_name',$users->admin_name);
              Session::put('id',$users->admin_id);
              Session::put('doctor_id',$users->doctor_id);
              Session::put('status',$users->status);

              
              return Redirect::to('/index');
           }
           elseif ($users->status==1) {
             Session::put('admin_name',$users->admin_name);
              Session::put('id',$users->admin_id);
              Session::put('doctor_id',$users->doctor_id);
              Session::put('status',$users->status);


              
              return Redirect::to('/index');
           }
           elseif($users->status==3){
             Session::put('admin_name',$users->admin_name);
              Session::put('id',$users->admin_id);
              Session::put('doctor_id',$users->doctor_id);
              Session::put('status',$users->status);


              
              return Redirect::to('/index');
           }
           else{
             Session::put('exception','Email or Password Invalid');
         return Redirect::to('/admin');
           }

             
              
        
      }
      else{
          Session::put('exception','Email or Password Invalid');
         return Redirect::to('/admin');
    }
}

    public function index()
    {
      $doctor_type=DB::table('tbl_doctor_type')->get()->count();
      $assistant=DB::table('tbl_assistant')->get()->count();
      $doctor=DB::table('tbl_doctor')->get()->count();
      $doctor_with_image=DB::table('tbl_doctor')->get();
      $prscription=DB::table('tbl_prscription')->get()->count();
       
               $dashboard=view('admin.dashboard')
                         ->with('doctor_type',$doctor_type)
                         ->with('assistant',$assistant)
                         ->with('doctor',$doctor)
                         ->with('doctor_with_image',$doctor_with_image)
                         ->with('prescription',$prscription);
               $footer=view('admin.footer');
               return view('loginmaster')
               ->with('content',$dashboard)
               ->with('footer',$footer);
        
    }
    public function addJob(){

               $dashboard=view('admin.addJob');
               $footer=view('admin.footer');
               return view('loginmaster')
               ->with('content',$dashboard)
               ->with('footer',$footer);

    }
    public function manageJob(){
              $dashboard=view('admin.manage');
               $footer=view('admin.footer');
               return view('loginmaster')
               ->with('content',$dashboard)
               ->with('footer',$footer);
    }
     public function addJobCategory(){
              $dashboard=view('admin.addJobCategory');
               $footer=view('admin.footer');
               return view('loginmaster')
               ->with('content',$dashboard)
               ->with('footer',$footer);
    }
     public function viewCategory(){
            $cat_info=DB::table('tbl_doctor_type')->get();
              $dashboard=view('admin.viewCategory')->with('allDoctorType',$cat_info);
               $footer=view('admin.footer');
               return view('loginmaster')
               ->with('content',$dashboard)
               ->with('footer',$footer);
    }
    public function viewDoctor(){
            $cat_info=DB::table('tbl_doctor_type')->get();
            $all_doctor=DB::table('tbl_doctor')->get();
              $dashboard=view('admin.viewAllDoctor')
                        ->with('allDoctorType',$cat_info)
                        ->with('all_doctor',$all_doctor);
               $footer=view('admin.footer');
               return view('loginmaster')
               ->with('content',$dashboard)
               ->with('footer',$footer);
    }
     public function addCompany(){
              $dashboard=view('admin.addCompany');
               $footer=view('admin.footer');
               return view('loginmaster')
               ->with('content',$dashboard)
               ->with('footer',$footer);
    }
     public function viewCompany(){
              $dashboard=view('admin.viewCompany');
               $footer=view('admin.footer');
               return view('loginmaster')
               ->with('content',$dashboard)
               ->with('footer',$footer);
    }
     public function viewallUser(){
              $dashboard=view('admin.viewallUser');
               $footer=view('admin.footer');
               return view('loginmaster')
               ->with('content',$dashboard)
               ->with('footer',$footer);
    }
      public function logout(){
        Session::put('admin_name',null);
        Session::put('id',null);
         Session::put('doctor_id',null);
              Session::put('status',null);
       
        return Redirect::to('/admin');
    }
     public function add_doctor_type(Request $request){
          $data=array();
         $data['type_name']=$request->type_name;
         if (!empty($data['type_name'])) {
           DB::table('tbl_doctor_type')->insert($data);
       Session::put('message','Save Doctor Type Successfully ');

        return Redirect::to('/addJobCategory');
         }
         else{
           Session::put('message','Name of Doctor Type Should not be empty ');
           return Redirect::to('/addJobCategory');
         }
       
    }
    public function editDoctorType($id){
      $cat_info=DB::table('tbl_doctor_type')
                ->where('type_id', $id)->first();

                $dashboard=view('admin.editDoctorType')->with('doctorType',$cat_info);
               $footer=view('admin.footer');
               return view('loginmaster')
               ->with('content',$dashboard)
               ->with('footer',$footer);

    }
     public function editDoctor($id){
      $cat_info=DB::table('tbl_doctor')
                ->where('doctor_id', $id)->first();
       $doctor_type=DB::table('tbl_doctor_type')->get();

                $dashboard=view('admin.editDoctor')->with('doctor',$cat_info)
                                                  ->with('doctor_type',$doctor_type);
               $footer=view('admin.footer');
               return view('loginmaster')
               ->with('content',$dashboard)
               ->with('footer',$footer);

    }
    public function edit_doctor_type(Request $request){
             $data=array();
         $data['type_name']=$request->type_name;
         $data['type_id']=$request->type_id;

         $affected = DB::table('tbl_doctor_type')
    ->where('type_id', $data['type_id'])
    ->update(['type_name' => $data['type_name']]);
   
    return Redirect::to('/viewCategory');
    }
    public function deleteDoctorType($id){
           DB::table('tbl_doctor_type')->where('type_id', $id)->delete();
    
            return Redirect::to('/viewCategory');
    }
     public function deleteDoctor($id){
           DB::table('tbl_doctor')->where('doctor_id', $id)->delete();
           $check=DB::table('tbl_admin')->where('doctor_id', $id)->first();
           if ($check) {
               DB::table('tbl_admin')->where('doctor_id', $id)->delete();
           }
    
            return Redirect::to('/viewDoctor');
    } 
    public function deleteAssistant($id){
           DB::table('tbl_assistant')->where('assistant_id', $id)->delete();
           $check=DB::table('tbl_admin')->where('assistant_id', $id)->first();
           if ($check) {
               DB::table('tbl_admin')->where('assistant_id', $id)->delete();
           }
    
            return Redirect::to('/viewAssistant');
    }
    public function addDoctor(){
       $cat_info=DB::table('tbl_doctor_type')->get();
      $dashboard=view('admin.addDoctor')->with('cat_info',$cat_info);
               $footer=view('admin.footer');
               return view('loginmaster')
               ->with('content',$dashboard)
               ->with('footer',$footer);

    }
    public function save_doctor(Request $request){
       $data=array();
         $data['doctor_type']=$request->doctor_type;
         $data['doctor_name']=$request->doctor_name;
         
          $request->validate([
            'img' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);
          $imageName = time().'.'.$request->img->extension(); 
        $upload_path='img/';
        $image_url=$upload_path . $imageName;
        $success=$request->img->move($upload_path,$imageName);
        $data['img']=$image_url;

         if (!empty($data['doctor_name'])) {
           DB::table('tbl_doctor')->insert($data);
       Session::put('message','Save Doctor Successfull ');

        return Redirect::to('/addDoctor');
         }
         else{
           Session::put('message','Name of Doctor  Should not be empty ');
           return Redirect::to('/addDoctor');
         }

    }
    public function update_doctor(Request $request){
         $data=array();
         $data['doctor_id']=$request->doctor_id;
         $data['doctor_type']=$request->doctor_type;
         $data['doctor_name']=$request->doctor_name;
         if($request->img != ''){ 

           unlink($request->prev_image); 

         $request->validate([
            'img' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);

  
        $imageName = time().'.'.$request->img->extension(); 
        $upload_path='img/';
        $image_url=$upload_path . $imageName;
        $success=$request->img->move($upload_path,$imageName);
        if ($success) {

           $data['img']=$image_url;
            $affected = DB::table('tbl_doctor')
    ->where('doctor_id', $data['doctor_id'])
    ->update($data);
   
    return Redirect::to('/viewDoctor');
        }
         }
         else{

         $affected = DB::table('tbl_doctor')
    ->where('doctor_id', $data['doctor_id'])
    ->update(['doctor_type' => $data['doctor_type'],'doctor_name' => $data['doctor_name']]);
   
    return Redirect::to('/viewDoctor');
  }
    }
     public function addAssistant(){
       $cat_info=DB::table('tbl_doctor_type')->get();
      $dashboard=view('admin.addAssistant')->with('cat_info',$cat_info);
               $footer=view('admin.footer');
               return view('loginmaster')
               ->with('content',$dashboard)
               ->with('footer',$footer);

    }
     public function viewDoctorasAdmin(){
            $cat_info=DB::table('tbl_doctor_type')->get();
            $all_doctor=DB::table('tbl_doctor')->get();
            $all_admin=DB::table('tbl_admin')->get();

              $dashboard=view('admin.viewDoctorasAdmin')
                        ->with('allDoctorType',$cat_info)
                        ->with('all_doctor',$all_doctor)
                        ->with('all_admin',$all_admin);
               $footer=view('admin.footer');
               return view('loginmaster')
               ->with('content',$dashboard)
               ->with('footer',$footer);
    }
    public function makedoctorAdmin($id){
          $cat_info=DB::table('tbl_doctor')
                    ->where('doctor_id', $id)->first();
                     $dashboard=view('admin.makedoctorAdmin')->with('doctor',$cat_info);
               $footer=view('admin.footer');
               return view('loginmaster')
               ->with('content',$dashboard)
               ->with('footer',$footer);
    }
    public function add_doctor_as_admin(Request $request){
      $data=array();
         $data['admin_name']=$request->admin_name;
         $data['admi_email_id']=$request->admi_email_id;
         $data['admin_password_id']= md5($request->admin_password_id);
         $data['status']=1;
         $data['doctor_id']=$request->doctor_id;
         if (!empty($data)) {
           DB::table('tbl_admin')->insert($data);
            DB::table('tbl_doctor')
    ->where('doctor_id', $data['doctor_id'])
    ->update(['admin_status' => 1]);
       Session::put('message','This Doctor is admin from now');

        return Redirect::to('/viewDoctorasAdmin');
         }
         else{
           Session::put('message','Your Input Field was empty');
           return Redirect::to('/viewDoctorasAdmin');
         }

    }
    public function suspendAdmin($id){
              $update=DB::table('tbl_admin')
               ->where('doctor_id',$id)
                ->update(['status' => 2]);
               
               return Redirect::to('/viewDoctorasAdmin');
    }
     public function makeAssistantActive($id){
              $update=DB::table('tbl_admin')
               ->where('assistant_id',$id)
                ->update(['status' => 3]);
               
               return Redirect::to('/viewAssistant');
    }
    public function makeAssistantdeActive($id){
              $update=DB::table('tbl_admin')
               ->where('assistant_id',$id)
                ->update(['status' => 4]);
               
               return Redirect::to('/viewAssistant');
    }
    public function returnDoctorAsAdmin($id){
              $update=DB::table('tbl_admin')
               ->where('doctor_id',$id)
                ->update(['status' => 1]);
               
               return Redirect::to('/viewDoctorasAdmin');
    }
    public function save_assistant(Request $request){
         $data=array();
         $data['assistant_name']=$request->assistant_name;
         $data['doctor_name']=Session::get('admin_name');
         $data['doctor_type']= Session::get('doctor_id');


         
         if (!empty($data)) {
           DB::table('tbl_assistant')->insert($data);
            
       Session::put('message','Your Assistant Has Been Added Successfully');

        return Redirect::to('/addAssistant');
         }
         else{
           Session::put('message','Your Input Field was empty');
           return Redirect::to('/addAssistant');
         }

    }
    public function viewAssistant(){
           $allAssistant=DB::table('tbl_assistant')
                         ->where('doctor_type',Session::get('doctor_id'))
                         ->get();
            $all_admin=DB::table('tbl_admin')->get();
            $dashboard=view('admin.allAssistant')
                         ->with('allAssistant',$allAssistant)
                         ->with('allAdmin',$all_admin);
               $footer=view('admin.footer');
               return view('loginmaster')
               ->with('content',$dashboard)
               ->with('footer',$footer);
    }
    public function viewAssistantasAdmin(){
           $allAssistant=DB::table('tbl_assistant')
                         ->get();
            $all_admin=DB::table('tbl_admin')->get();
            $dashboard=view('admin.allAssistantviesasadmin')
                         ->with('allAssistant',$allAssistant)
                         ->with('allAdmin',$all_admin);
               $footer=view('admin.footer');
               return view('loginmaster')
               ->with('content',$dashboard)
               ->with('footer',$footer);
    }
    public function editAssistant($id){
               $cat_info=DB::table('tbl_assistant')
                        ->where('assistant_id', $id)->first();
               

                $dashboard=view('admin.editAssistant')->with('assistant',$cat_info);
               $footer=view('admin.footer');
               return view('loginmaster')
               ->with('content',$dashboard)
               ->with('footer',$footer);
    }
    public function update_assistant(Request $request){
            $data=array();
         $data['assistant_name']=$request->assistant_name;
         $data['assistant_id']=$request->assistant_id;
         if (!empty($data)) {
           
            DB::table('tbl_assistant')
    ->where('assistant_id', $data['assistant_id'])
    ->update(['assistant_name' => $data['assistant_name']]);
       Session::put('message','Assistant Updated');

        return Redirect::to('/viewAssistant');
         }
         else{
           Session::put('message','Your Input Field was empty');
           return Redirect::to('/viewAssistant');
         }

    }
    public function save_Prescription(Request $request){
       $data=array();
         $data['patient_name']=$request->patient_name;
         
         $docInfo=DB::table('tbl_doctor')
                  ->where('doctor_id', Session::get('doctor_id'))->first();
         $data['doctor_name']=$docInfo->doctor_name;
         $doctor_designation=DB::table('tbl_doctor_type')
                  ->where('type_id',$docInfo->doctor_type)->first();
         $data['doctor_designation']=$doctor_designation->type_name;
         $data['patient_age']=$request->patient_age;
         $data['patient_gender']=$request->patient_gender;
         $data['prescription_body']=$request->prescription_body;
         $data['doctor_id']=$docInfo->doctor_id;
         if (!empty($data)) {
           
           DB::table('tbl_prscription')->insert($data);
          Session::put('message','Prescription Can Found now on Finance Section');

        return Redirect::to('/viewallUser');
         }
         else{
           Session::put('message','Your Input Field was empty');
           return Redirect::to('/viewallUser');
         }

    }
    public function viewallPrescription(){
           $allAssistant=DB::table('tbl_prscription')
            ->where('doctor_id', Session::get('doctor_id'))
            ->get();
            $dashboard=view('admin.allAppointment')
                         ->with('allAppointment',$allAssistant);
               $footer=view('admin.footer');
               return view('loginmaster')
               ->with('content',$dashboard)
               ->with('footer',$footer);

    }
     public function viewallPrescriptionAsAdmin(){
           $allAssistant=DB::table('tbl_prscription')
            ->get();
            $dashboard=view('admin.allAppointment')
                         ->with('allAppointment',$allAssistant);
               $footer=view('admin.footer');
               return view('loginmaster')
               ->with('content',$dashboard)
               ->with('footer',$footer);

    }
    public function addSchedule(){
              
              

               $dashboard=view('admin.addSchedule');
               $footer=view('admin.footer');
               return view('loginmaster')
               ->with('content',$dashboard)
               ->with('footer',$footer);
    }
    public function save_schedule(Request $request){
       $data=array();
         $data['moorning']=$request->moorning;
         $data['afternoon']=$request->afternoon;
         $data['moorning_place']=$request->moorning_place;
         $data['Evening']=$request->Evening;
         $data['night']=$request->night;
         $data['afternoon_place']=$request->afternoon_place;
         $data['night_plcae']=$request->night_plcae;
         $data['evening_plcae']=$request->evening_plcae;
         $docInfo=DB::table('tbl_doctor')
                  ->where('doctor_id', Session::get('doctor_id'))->first();
         
         $data['doctor_name']=$docInfo->doctor_name;
         $data['doctor_type']=$docInfo->doctor_type;
         $data['doctor_id']=Session::get('doctor_id');
         
         if (!empty($data)) {
           
           DB::table('tbl_doctor_schedule')->insert($data);
          Session::put('message','This Schedule Can Found to our website from now');

        return Redirect::to('/viewallUser');
         }
         else{
           Session::put('message','Your Input Field was empty');
           return Redirect::to('/viewallUser');
         }

    }
    public function viewAllSchedule(){
            $viewAllSchedule=DB::table('tbl_doctor_schedule')
                             ->where('doctor_id', Session::get('doctor_id'))
                             ->first();
              $dashboard=view('admin.viewAllSchedule')
                        ->with('viewAllSchedule',$viewAllSchedule);
               $footer=view('admin.footer');
               return view('loginmaster')
               ->with('content',$dashboard)
               ->with('footer',$footer);
    }
    public function viewAllScheduleAsAdmin(){
            $viewAllSchedule=DB::table('tbl_doctor_schedule')
                             ->get();
              $dashboard=view('admin.viewAllScheduleAsAdmin')
                        ->with('viewAllSchedule',$viewAllSchedule);
               $footer=view('admin.footer');
               return view('loginmaster')
               ->with('content',$dashboard)
               ->with('footer',$footer);
    }
    public function editShedule($id){

           $allSchedule=DB::table('tbl_doctor_schedule')
                  ->where('id', $id)->first();
          $dashboard=view('admin.editSchedule')
                      ->with('allSchedule',$allSchedule);
               $footer=view('admin.footer');
               return view('loginmaster')
               ->with('content',$dashboard)
               ->with('footer',$footer);

    }
    public function update_schedule(Request $request){
       $data=array();
            $data['moorning']=$request->moorning;
         $data['afternoon']=$request->afternoon;
         $data['moorning_place']=$request->moorning_place;
         $data['Evening']=$request->Evening;
         $data['night']=$request->night;
         $data['afternoon_place']=$request->afternoon_place;
         $data['night_plcae']=$request->night_plcae;
         $data['evening_plcae']=$request->evening_plcae;
         $data['id']=$request->id;
         if (!empty($data)) {

            DB::table('tbl_doctor_schedule')
    ->where('id', $data['id'])
    ->update($data);
       Session::put('message','Schedule Updated');

        return Redirect::to('/viewAllSchedule');
         }

    }
    public function deleteShedule($id){
         DB::table('tbl_doctor_schedule')->where('id', $id)->delete();
    
            return Redirect::to('/viewAllSchedule');
    }
     public function makePaymentOk($id){
              $update=DB::table('tbl_prscription')
               ->where('patient_id',$id)
                ->update(['payment_status' => 1]);
               
               return Redirect::to('/viewallPrescription');
    }
  public function dawonloadPrescription($id){
         $pdf = \App::make('dompdf.wrapper');
     $pdf->loadHTML($this->convert_customer_data_to_html($id));
     return $pdf->stream();
  }
   function convert_customer_data_to_html($id)
    {
    $customer_data =  DB::table('tbl_prscription')
    ->where('patient_id', $id)->first();
     $output = '
    
     
      <h2 class="text-left text-capitalize font-weight-bold">
      Doctor Name:
      </h2>
      <span class="font-italic">'.$customer_data->doctor_name.'</span>
       <h2 class="text-left text-capitalize font-weight-bold">
      Doctor Designation:
      </h2>
      <span class="font-italic">'.$customer_data->doctor_designation.'</span>
      <h2 class="text-left text-capitalize font-weight-bold">
      Patient Name:
      </h2>
      <span class="font-italic">'.$customer_data->patient_name.'</span>
       <h2 class="text-left text-capitalize font-weight-bold">
      Patient Age:
      </h2>
      <span class="font-italic">'.$customer_data->patient_age.'</span>
       <h2 class="text-left text-capitalize font-weight-bold">
      Patient Gender:
      </h2>
      <span class="font-italic">'.$customer_data->patient_gender.'</span>
       <hr>
         <hr>
         
       <h2 class="text-left text-capitalize font-weight-bold">
      Prescription:
      </h2>
      <span class="font-italic">'.$customer_data->prescription_body.'</span>
   
     ';  
     
     $output .= '</table>';
     return $output;
    }
    public function makeAssistantAdmin($id){
       $cat_info=DB::table('tbl_assistant')
                    ->where('assistant_id', $id)->first();
                     $dashboard=view('admin.makeAssistantAdmin')->with('doctor',$cat_info);
               $footer=view('admin.footer');
               return view('loginmaster')
               ->with('content',$dashboard)
               ->with('footer',$footer);
    }
    public function save_assistant_as_admin(Request $request){
       $data=array();
         $data['admin_name']=$request->admin_name;
         $data['admi_email_id']=$request->admi_email_id;
         $data['admin_password_id']= md5($request->admin_password_id);
         $data['status']=3;
         $data['doctor_id']=Session::get('doctor_id');
         $data['assistant_id']=$request->assistant_id;
         if (!empty($data)) {
           DB::table('tbl_admin')->insert($data);
            DB::table('tbl_doctor')
    ->where('doctor_id', $data['doctor_id'])
    ->update(['admin_status' => 1]);
       Session::put('message','This Doctor is admin from now');

        return Redirect::to('/viewAssistant');
         }
         else{
           Session::put('message','Your Input Field was empty');
           return Redirect::to('/viewAssistant');
         }
    }
    public function viewallMessage(){

            $news_info=DB::table('tbl_message')->get();

              $dashboard=view('admin.viewMessage')->with('all_news_info',$news_info);
               $footer=view('admin.footer');
               return view('loginmaster')
               ->with('content',$dashboard)
               ->with('footer',$footer);
}
public function viewallTickerAsAdmin(){

            $news_info=DB::table('tbl_ticket')->get();

              $dashboard=view('admin.viewAllticket')->with('all_news_info',$news_info);
               $footer=view('admin.footer');
               return view('loginmaster')
               ->with('content',$dashboard)
               ->with('footer',$footer);
}
public function delete_message($category_id){
       
    DB::table('tbl_message')->where('ms_id', $category_id)->delete();
    
   return Redirect::to('/viewallMessage');
}
public function viewallTicker(){
 
  $news_info=DB::table('tbl_ticket')
  ->where('doctor_id', Session::get('doctor_id'))
  ->get();

              $dashboard=view('admin.viewAllticket')
              ->with('all_news_info',$news_info);
               $footer=view('admin.footer');
               return view('loginmaster')
               ->with('content',$dashboard)
               ->with('footer',$footer);

}

   


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
