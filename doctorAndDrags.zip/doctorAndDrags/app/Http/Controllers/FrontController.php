<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Redirect;

use Illuminate\Http\Request;
use Session;
use DB;
use PDF;
session_start();

class FrontController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $doctor_type=DB::table('tbl_doctor_type')->get();
        $doctor=DB::table('tbl_doctor')->get();
       

        $home_content=view('pages.header');
        $body=view('pages.page')->with('doctor_type',$doctor_type)
                                ->with('doctor',$doctor);
        $category=view('pages.footer');
        return view('master')
        ->with('head',$home_content)
        ->with('body',$body)
        ->with('tail',$category);
    }
    public function DoctorByType(Request $request){
        $data['doctor_type']=$request->doctor_type;
        $doctor = DB::table('tbl_doctor')
                 ->where('doctor_type',$data['doctor_type'])
                 ->get();
        $doctor_type=DB::table('tbl_doctor_type')
                    ->where('type_id',$data['doctor_type'])
                    ->first();
        $home_content=view('pages.header');
        $body=view('pages.DoctorByType')->with('doctor',$doctor)
                                        ->with('doctor_type',$doctor_type);
        $category=view('pages.footer');
        return view('master')
        ->with('head',$home_content)
        ->with('body',$body)
        ->with('tail',$category);

    }
    public function showDoctorById($id){
        $doctorSchedule = DB::table('tbl_doctor_schedule')
                  ->where('doctor_id',$id)
                 ->first();
        $home_content=view('pages.header');
        $body=view('pages.doctorSchedule')->with('viewAllSchedule',$doctorSchedule);
        $category=view('pages.footer');
        return view('master')
        ->with('head',$home_content)
        ->with('body',$body)
        ->with('tail',$category);

    }
    public function sendMessage(Request $request){
         $data['message_body']=$request->message_body;
        $data['messerger_name']=$request->messerger_name;
        $data['messager_email']=$request->messager_email;
        $data['message_subject']=$request->message_subject;
      

        if (empty($data['message_body'])) {
            Session::put('message','Please Enter Your Name');
            return Redirect::to('/');
        }
        elseif (empty($data['messerger_name'])) {
            Session::put('message','Please Enter Your Email');
            return Redirect::to('/');
        }
        elseif (empty($data['messager_email'])) {
            Session::put('message','Please Give a Password');
            return Redirect::to('/');
        }
        else{
           
        DB::table('tbl_message')->insert($data);
       Session::put('message','Your Message Successfully Sent');

        return Redirect::to('/');
    }
}
public function DoctorsTicket(Request $request){

    $data['doctor_id']=$request->doctor_id;
    $data['Patient_name']=$request->Patient_name;
    $data['time']=$request->time;
     $doc_name=DB::table('tbl_doctor')->where('doctor_id', $data['doctor_id'])->first();
    $data['doctor_name']=$doc_name->doctor_name;
     DB::table('tbl_ticket')->insert($data);
     $last=DB::table('tbl_ticket')->orderBy('ticket_id', 'DESC')->first();
     Session::put('message','Your Ticker Number = '.$last->ticket_id.'');

        return Redirect::to('/');

}

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
