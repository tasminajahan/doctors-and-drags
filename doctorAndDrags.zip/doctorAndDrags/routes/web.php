<?php


use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/','App\Http\Controllers\FrontController@index');
Route::post('DoctorByType','App\Http\Controllers\FrontController@DoctorByType');
Route::post('sendMessage','App\Http\Controllers\FrontController@sendMessage');
Route::post('DoctorsTicket','App\Http\Controllers\FrontController@DoctorsTicket');
Route::get('/viewallTickerAsAdmin','App\Http\Controllers\AdminController@viewallTickerAsAdmin');
Route::get('/viewallTicker','App\Http\Controllers\AdminController@viewallTicker');
Route::get('/showDoctorById/{id}','App\Http\Controllers\FrontController@showDoctorById');

/*
Admin Start From Here
-----------------------------
*/
Route::get('/admin','App\Http\Controllers\AdminController@login');
Route::post('/admin_login_check','App\Http\Controllers\AdminController@admin_login_check');
Route::get('/index','App\Http\Controllers\AdminController@index');
Route::get('/addJob','App\Http\Controllers\AdminController@addJob');
Route::get('/manageJob','App\Http\Controllers\AdminController@manageJob');
Route::get('/addJobCategory','App\Http\Controllers\AdminController@addJobCategory');
Route::get('/viewCategory','App\Http\Controllers\AdminController@viewCategory');
Route::get('/viewDoctor','App\Http\Controllers\AdminController@viewDoctor');
Route::get('/addCompany','App\Http\Controllers\AdminController@addCompany');
Route::get('/viewCompany','App\Http\Controllers\AdminController@viewCompany');
Route::get('/viewallUser','App\Http\Controllers\AdminController@viewallUser');
Route::get('/logout','App\Http\Controllers\AdminController@logout');
Route::post('/add_doctor_type','App\Http\Controllers\AdminController@add_doctor_type');
Route::get('/editDoctorType/{id}','App\Http\Controllers\AdminController@editDoctorType');
Route::get('/editAssistant/{id}','App\Http\Controllers\AdminController@editAssistant');
Route::get('/editDoctor/{id}','App\Http\Controllers\AdminController@editDoctor');
Route::get('/deleteDoctor/{id}','App\Http\Controllers\AdminController@deleteDoctor');
Route::get('/deleteDoctorType/{id}','App\Http\Controllers\AdminController@deleteDoctorType');
Route::get('/deleteAssistant/{id}','App\Http\Controllers\AdminController@deleteAssistant');
Route::get('/makedoctorAdmin/{id}','App\Http\Controllers\AdminController@makedoctorAdmin');
Route::get('/deleteShedule/{id}','App\Http\Controllers\AdminController@deleteShedule');
Route::get('/editShedule/{id}','App\Http\Controllers\AdminController@editShedule');
Route::get('/suspendAdmin/{id}','App\Http\Controllers\AdminController@suspendAdmin');
Route::get('/makeAssistantActive/{id}','App\Http\Controllers\AdminController@makeAssistantActive');
Route::get('/makeAssistantdeActive/{id}','App\Http\Controllers\AdminController@makeAssistantdeActive');
Route::get('/makePaymentOk/{id}','App\Http\Controllers\AdminController@makePaymentOk');
Route::get('/makeAssistantAdmin/{id}','App\Http\Controllers\AdminController@makeAssistantAdmin');
Route::get('/dawonloadPrescription/{id}','App\Http\Controllers\AdminController@dawonloadPrescription');
Route::get('/returnDoctorAsAdmin/{id}','App\Http\Controllers\AdminController@returnDoctorAsAdmin');

Route::post('/edit_doctor_type','App\Http\Controllers\AdminController@edit_doctor_type');
Route::post('/update_doctor','App\Http\Controllers\AdminController@update_doctor');
Route::get('/addDoctor','App\Http\Controllers\AdminController@addDoctor');
Route::post('/save_doctor','App\Http\Controllers\AdminController@save_doctor');
Route::get('/addAssistant','App\Http\Controllers\AdminController@addAssistant');
Route::get('/viewDoctorasAdmin','App\Http\Controllers\AdminController@viewDoctorasAdmin');
Route::get('/viewAllSchedule','App\Http\Controllers\AdminController@viewAllSchedule');
Route::get('/viewAllScheduleAsAdmin','App\Http\Controllers\AdminController@viewAllScheduleAsAdmin');
Route::get('/viewAssistant','App\Http\Controllers\AdminController@viewAssistant');
Route::get('/viewallPrescription','App\Http\Controllers\AdminController@viewallPrescription');
Route::get('/viewallPrescriptionAsAdmin','App\Http\Controllers\AdminController@viewallPrescriptionAsAdmin');
Route::get('/viewAssistantasAdmin','App\Http\Controllers\AdminController@viewAssistantasAdmin');
Route::post('/add_doctor_as_admin','App\Http\Controllers\AdminController@add_doctor_as_admin');
Route::get('/addSchedule','App\Http\Controllers\AdminController@addSchedule');
Route::post('/save_assistant','App\Http\Controllers\AdminController@save_assistant');
Route::post('/update_assistant','App\Http\Controllers\AdminController@update_assistant');
Route::post('/save_Prescription','App\Http\Controllers\AdminController@save_Prescription');
Route::post('/save_schedule','App\Http\Controllers\AdminController@save_schedule');
Route::post('/update_schedule','App\Http\Controllers\AdminController@update_schedule');
Route::post('/save_assistant_as_admin','App\Http\Controllers\AdminController@save_assistant_as_admin');
Route::get('/viewallMessage','App\Http\Controllers\AdminController@viewallMessage');
Route::get('/delete_message/{id}','App\Http\Controllers\AdminController@delete_message');

