@extends('master')
@section('body')
			<noscript>
				<div class="alert alert-block span10">
					<h4 class="alert-heading">Warning!</h4>
					<p>You need to have <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a> enabled to use this site.</p>
				</div>
			</noscript>
			
			<!-- start: Content -->
			<div id="content" class="span10">
	
			
			<ul class="breadcrumb">
				<li>
					<i class="icon-home"></i>
					<a href="index.html">All</a> 
					<i class="icon-angle-right"></i>
				</li>
				<li><a href="#">Doctor Type</a></li>
			</ul>

			<div class="row-fluid sortable" style="height: 1000px">		
				<div class="box span12">
					<div class="box-header" data-original-title>
						<h2><i class="halflings-icon white user"></i><span class="break"></span>Types</h2>
						<div class="box-icon">
							<a href="#" class="btn-setting"><i class="halflings-icon white wrench"></i></a>
							<a href="#" class="btn-minimize"><i class="halflings-icon white chevron-up"></i></a>
							<a href="#" class="btn-close"><i class="halflings-icon white remove"></i></a>
						</div>
					</div>
					<div class="box-content">
						<h3 style="color:green">
                    <?php
                     $message=Session::get('message');
                     if($message){
                         echo $message;
                         Session::put('message',null);
                     }
                    ?>
                    </h3>
                    <?php 
                    if (!empty($viewAllSchedule)) {
                    	# code...
                   
                     ?>
                    <h1 class="team-heading text-center" style="margin-top: 10%"><?php echo $viewAllSchedule->doctor_name; ?></h1>
						<table class="table table-striped table-bordered bootstrap-datatable datatable">
						  <thead>
							  <tr>
								  <th>Doctor Name</th>
								  <?php 
								      if (!empty($viewAllSchedule->moorning)) {
								      	# code...
								      
								   ?>
								  <th>Moorning Time</th>
								<?php } ?>
								<?php 
								      if (!empty($viewAllSchedule->moorning_place)) {
								      	# code...
								      
								   ?>
								  <th>Moorning Place</th>
								<?php } ?>
								<?php 
								      if (!empty($viewAllSchedule->afternoon)) {
								      	# code...
								      
								   ?>
								  <th>Afternoon Time</th>
								<?php } ?>
								<?php 
								      if (!empty($viewAllSchedule->afternoon_place)) {
								      	# code...
								      
								   ?>
								  <th>Afternoon Place</th>
								<?php } ?>
								<?php 
								      if (!empty($viewAllSchedule->Evening)) {
								      	# code...
								      
								   ?>
								  <th>Evening Time</th>
								<?php } ?>
								<?php 
								      if (!empty($viewAllSchedule->evening_plcae)) {
								      	# code...
								      
								   ?>
								  <th>Evening Place</th>
								<?php } ?>
								<?php 
								      if (!empty($viewAllSchedule->night)) {
								      	# code...
								      
								   ?>
								  <th>Night Time</th>
								<?php } ?>
								<?php 
								      if (!empty($viewAllSchedule->night_plcae)) {
								      	# code...
								      
								   ?>
								  <th>Night Place</th>
								<?php } ?>
							  </tr>
						  </thead>   
						  <tbody>
						  	
							<tr>
								<td><?php echo $viewAllSchedule->doctor_name  ?></td>
								
								 <?php 
								      if (!empty($viewAllSchedule->moorning)) {
								      	# code...
								      
								   ?>
								  <td><?php echo $viewAllSchedule->moorning ?></td>
								<?php } ?>
																<?php 
								      if (!empty($viewAllSchedule->moorning_place)) {
								      	# code...
								      
								   ?>
								  <td><?php echo $viewAllSchedule->moorning_place ?></td>
								<?php } ?>
								<?php 
								      if (!empty($viewAllSchedule->afternoon)) {
								      	# code...
								      
								   ?>
								  <td><?php echo $viewAllSchedule->afternoon ?></td>
								<?php } ?>
								<?php 
								      if (!empty($viewAllSchedule->afternoon_place)) {
								      	# code...
								      
								   ?>
								  <td><?php echo $viewAllSchedule->afternoon_place ?></td>
								<?php } ?>
								<?php 
								      if (!empty($viewAllSchedule->Evening)) {
								      	# code...
								      
								   ?>
								  <td><?php echo $viewAllSchedule->Evening ?></td>
								<?php } ?>
								<?php 
								      if (!empty($viewAllSchedule->evening_plcae)) {
								      	# code...
								      
								   ?>
								  <td><?php echo $viewAllSchedule->evening_plcae ?></td>
								<?php } ?>
								<?php 
								      if (!empty($viewAllSchedule->night)) {
								      	# code...
								      
								   ?>
								  <td><?php echo $viewAllSchedule->night ?></td>
								<?php } ?>
								<?php 
								      if (!empty($viewAllSchedule->night_plcae)) {
								      	# code...
								      
								   ?>
								  <td><?php echo $viewAllSchedule->night_plcae ?> </td>
								<?php } ?>
								
								
								
								
							</tr>
						
							
							
							
							
							
						  </tbody>
					  </table>  
					  <?php }else{ ?> 
					  	<h1 class="team-heading text-center" style="margin-top: 10%">This Doctor Still now do not have any schedule</h1>
					  <?php } ?>         
					</div>
				</div><!--/span-->
			
			</div><!--/row-->

			
			<!-- end: Content -->
									@endsection
