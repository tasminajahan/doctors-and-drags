@extends('master')
@section('body')
<section class="slider" id="home">
		<div class="container-fluid">
			<div class="row">
			    <div id="carouselHacked" class="carousel slide carousel-fade" data-ride="carousel">
					<div class="header-backup"></div>
			        <!-- Wrapper for slides -->
			        <div class="carousel-inner" role="listbox">
			            <div class="item active">
			            	<img src="{{URL::to('public/img/slide-one.jpg')}}" alt="">
			                <div class="carousel-caption">
		               		
			                </div>
			            </div>
			            <div class="item">
			            	<img src="{{URL::to('public/img/slide-two.jpg')}}" alt="">
			                <div class="carousel-caption">
		               			<h1>providing</h1>
		               			<p>highquality service for men &amp; women</p>
		               			<button>learn more</button>
			                </div>
			            </div>
			            <div class="item">
			            	<img src="{{URL::to('public/img/slide-three.jpg')}}" alt="">
			                <div class="carousel-caption">
		               			<h1>providing</h1>
		               			<p>highquality service for men &amp; women</p>
		               			<button>learn more</button>
			                </div>
			            </div>
			            <div class="item">
			            	<img src="{{URL::to('public/img/slide-four.jpg')}}" alt="">
			                <div class="carousel-caption">
		               			<h1>providing</h1>
		               			<p>highquality service for men &amp; women</p>
		               			<button>learn more</button>
			                </div>
			            </div>
			        </div>
			        <!-- Controls -->
			        <a class="left carousel-control" href="#carouselHacked" role="button" data-slide="prev">
			            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
			            <span class="sr-only">Previous</span>
			        </a>
			        <a class="right carousel-control" href="#carouselHacked" role="button" data-slide="next">
			            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
			            <span class="sr-only">Next</span>
			        </a>
			    </div>
			</div>
		</div>
	</section><!-- end of slider section -->
	
	<section class="about text-center" id="about" style="margin-bottom: 20%;margin-top: 10%">
		<div class="container">
			<div class="row">
				<h2>Find Your Doctor By Demand</h2>
				<h4 style="margin-top: 5%"><div class="row">
                           {!! Form::open(['url' => '/DoctorByType','method' => 'post','enctype'=>'multipart/form-data']) !!}
                           <select class="form-select" aria-label="" name="doctor_type">
                            <option selected>Search Your Doctor</option>
                           <?php
                           foreach ($doctor_type as $city) {
                                # code...
                            
                            ?>
                            
  
  <option value="<?php echo $city->type_id ?>"><?php echo $city->type_name ?></option>
  

<?php } ?>
</select>
<button type="Submit" class="btn btn-primary btn-lg">Submit</button>
{!! Form::close() !!}
                        </div></h4>
			</div>
		</div>
	</section><!-- end of about section -->

	<!-- about section -->
	<section class="about text-center" id="about">
		<div class="container">
			<div class="row">
				<h2>about us</h2>
				<h4>We are happy to Serve you doctor's touch</h4>
				<div class="col-md-4 col-sm-6">
					<div class="single-about-detail clearfix">
						<div class="about-img">
							<img class="img-responsive" src="{{URL::to('public/img/item1.jpg')}}" alt="">
						</div>
						<div class="about-details">
							<div class="pentagon-text">
								<h1>C</h1>
							</div>
							<h3>Children’s specialist</h3>
							<p>You can find children specialist</p>
						</div>
					</div>
				</div>
				<div class="col-md-4 col-sm-6">
					<div class="single-about-detail">
						<div class="about-img">
							<img class="img-responsive" src="{{URL::to('public/img/item2.jpg')}}" alt="">
						</div>
						<div class="about-details">
							<div class="pentagon-text">
								<h1>W</h1>
							</div>

							<h3>Womens’s specialist</h3>
							<p>We have too many specialist for Women.</p>
						</div>
					</div>
				</div>
				<div class="col-md-4 col-sm-6">
					<div class="single-about-detail">
						<div class="about-img">
							<img class="img-responsive" src="{{URL::to('public/img/item3.jpg')}}" alt="">
						</div>
						<div class="about-details">
							<div class="pentagon-text">
								<h1>M</h1>
							</div>
							<h3>Chardiology specialist</h3>
							<p>This is our main concern, we have expart for this sensitive system</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section><!-- end of about section -->


	<!-- service section starts here -->
	<section class="service text-center" id="service">
		<div class="container">
			<div class="row">
				<h2>Doctor's Ticket</h2>
				<h4>We give the opportunity to  patient</h4>
				<div class="col-md-12 col-sm-6">

					{!! Form::open(['url' => '/DoctorsTicket','method' => 'post','enctype'=>'multipart/form-data']) !!}
					<div class="single-service">
						<h3 style="color:green">
                    <?php
                     $message=Session::get('message');
                     if($message){
                         echo $message;
                         Session::put('message',null);
                     }
                    ?>
                    </h3>
						<label class="h3" type="text"  placeholder="Publication Status"  value="" / style="color:white">Doctor Name</label>
							  <div class="controls">
								<select name="doctor_id">
								<?php
								 foreach($doctor as $doct){  
								 	foreach ($doctor_type as $type) {
								 		if ($type->type_id==$doct->doctor_type) {
								 			# code...
								 		
								 ?>
								 
							<option class="form-control input-lg" value="<?php echo $doct->doctor_id ?>">
								<?php echo $doct->doctor_name ?>
							 (<?php echo $type->type_name ?>)</option>

							
                                 <?php }
								 		# code...
								 	}
                             } ?>
							</select>
							<br>
							<label class="h3" type="text"  placeholder="Publication Status"  value="" / style="color:white">Time</label>
							<div class="controls">
								<select name="time">
									<option value="1" class="form-control input-lg">Moorning</option>
									<option value="2" class="form-control input-lg">Afternoon</option>
									<option value="3" class="form-control input-lg">Evening</option>
									<option value="4" class="form-control input-lg">Night</option>
								</select>
							</div>
							<br>
								<label class="h3" style="color:white">Patients Name:</label>
							<div class="controls">
								
								<input type="text" name="Patient_name" class="form-control-plaintext">
							</div>
							<button type="Submit" class="btn btn-primary btn-lg" style="margin-top: 2%;margin-bottom: 2%">Submit</button>
							  </div>
					
					</div>
					{!! Form::close() !!}
				</div>
			</div>
		</div>
	</section><!-- end of service section -->


	<!-- team section -->
	<section class="team" id="team">
		<div class="container">
			<div class="row">
				<div class="team-heading text-center">
					<h2>our team</h2>
					<h4>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled</h4>
				</div>
				<?php 
				foreach ($doctor as $doc) {
					# code...
				
				 ?>
				 <a href="{{URL::to('/showDoctorById',$doc->doctor_id )}}">
				<div class="col-md-4 single-member col-sm-4">
					<div class="person">
						<img style="max-width:100%;height:280px" class="img-responsive" src="<?php echo $doc->img ?>" alt="member-1">
					</div>
					<div class="person-detail">
						<div class="arrow-bottom"></div>
						<h3><?php echo $doc->doctor_name ?></h3>
						<?php 
						foreach ($doctor_type as $dt) {
							# code...
						if ($dt->type_id==$doc->doctor_type) {
							# code...
						
						 ?>
						<p><?php echo $dt->type_name ?> </p>
					<?php } 
				} ?>
					</div>
				</div>
				</a>
			<?php } ?>
			</div>
		</div>
	</section><!-- end of team section -->

	<!-- map section -->
	<div class="api-map" id="contact">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12 map" id="map"></div>
			</div>
		</div>
	</div><!-- end of map section -->

	<!-- contact section starts here -->
	<section class="contact">
		<div class="container">
			<div class="row">
				<div class="contact-caption clearfix">
					<div class="contact-heading text-center">
						<h2>contact us</h2>
					</div>
					<div class="col-md-5 contact-info text-left">
						<h3>contact information</h3>
						<div class="info-detail">
							<ul><li><i class="fa fa-calendar"></i><span>Monday - Friday:</span> 9:30 AM to 6:30 PM</li></ul>
							<ul><li><i class="fa fa-map-marker"></i><span>Address:</span> 123 Some Street , Zindabazar,Sylhet CP 123</li></ul>
							<ul><li><i class="fa fa-phone"></i><span>Phone:</span> (032) 987-1235</li></ul>
							<ul><li><i class="fa fa-fax"></i><span>Fax:</span> (123) 984-1234</li></ul>
							<ul><li><i class="fa fa-envelope"></i><span>Email:</span> info@doctor.com</li></ul>
						</div>
					</div>
					<div class="col-md-6 col-md-offset-1 contact-form">
						<h3>leave us a message</h3>
						 <h3 style="color:green">
                    <?php
                     $message=Session::get('message');
                     if($message){
                         echo $message;
                         Session::put('message',null);
                     }
                    ?>
                    </h3>

						{!! Form::open(['url' => '/sendMessage','method' => 'post','enctype'=>'multipart/form-data']) !!}
							<input class="name" type="text" placeholder="Name" name="messerger_name">
							<input class="email" type="email" placeholder="Email" name="messager_email">
							<input class="text" type="text" placeholder="Subject:" name="message_subject">
							<textarea class="message" name="message_body" id="message" cols="30" rows="10" placeholder="Message" ></textarea>
							<input class="submit-btn" type="submit" value="SUBMIT">
						  {!! Form::close() !!}
					</div>
				</div>
			</div>
		</div>
	</section><!-- end of contact section -->
@endsection