	@extends('loginmaster')
@section('content')	
			<noscript>
				<div class="alert alert-block span10">
					<h4 class="alert-heading">Warning!</h4>
					<p>You need to have <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a> enabled to use this site.</p>
				</div>
			</noscript>
			
			<!-- start: Content -->
			<div id="content" class="span10">
	
			
			<ul class="breadcrumb">
				<li>
					<i class="icon-home"></i>
					<a href="index.html">All</a> 
					<i class="icon-angle-right"></i>
				</li>
				<li><a href="#">Doctor Type</a></li>
			</ul>

			<div class="row-fluid sortable" style="height: 1000px">		
				<div class="box span12">
					<div class="box-header" data-original-title>
						<h2><i class="halflings-icon white user"></i><span class="break"></span>Types</h2>
						<div class="box-icon">
							<a href="#" class="btn-setting"><i class="halflings-icon white wrench"></i></a>
							<a href="#" class="btn-minimize"><i class="halflings-icon white chevron-up"></i></a>
							<a href="#" class="btn-close"><i class="halflings-icon white remove"></i></a>
						</div>
					</div>
					<div class="box-content">
						<h3 style="color:green">
                    <?php
                     $message=Session::get('message');
                     if($message){
                         echo $message;
                         Session::put('message',null);
                     }
                    ?>
                    </h3>
                   
						<table class="table table-striped table-bordered bootstrap-datatable datatable">
						  <thead>
							  <tr>
								  <th>Doctor Name</th>
								 
								  <th>Moorning Time</th>
								
								  <th>Moorning Place</th>
								
								  <th>Afternoon Time</th>
								
								  <th>Afternoon Place</th>
								
								  <th>Evening Time</th>
								
								  <th>Evening Place</th>
								
								  <th>Night Time</th>
								
								  <th>Night Place</th>
								 
								  <th>Actions</th>
							  </tr>
						  </thead>   
						  <tbody>
						  	<?php 
						  	foreach ($viewAllSchedule as $viewAllSchedule) {
						  		# code...
						  	
						  	 ?>
						  	
							<tr>
								<td><?php echo $viewAllSchedule->doctor_name  ?></td>
								  <td><?php echo $viewAllSchedule->moorning ?></td>
								
								  <td><?php echo $viewAllSchedule->moorning_place ?></td>
								  <td><?php echo $viewAllSchedule->afternoon ?></td>
								  <td><?php echo $viewAllSchedule->afternoon_place ?></td>
								  <td><?php echo $viewAllSchedule->Evening ?></td>
								  <td><?php echo $viewAllSchedule->evening_plcae ?></td>
								  <td><?php echo $viewAllSchedule->night ?></td>
								  <td><?php echo $viewAllSchedule->night_plcae ?> </td>
							
								
								
								
								<td class="center">
									<?php
									if (Session::get('status')==1) {
									 	# code...
									

									 ?>
									<a class="btn btn-info" href="{{URL::to('/editShedule',$viewAllSchedule->id )}}" >
										<i class="halflings-icon white edit"></i>  
									</a>
								<?php } ?>
									<a class="btn btn-danger" href="{{URL::to('/deleteShedule',$viewAllSchedule->id )}}" onclick="return confirm('Are you sure?')">
										<i class="halflings-icon white trash"></i> 
									</a>
								</td>
							</tr>
						<?php } ?>
						
							
							
							
							
							
						  </tbody>
					  </table> 
					          
					</div>
				</div><!--/span-->
			
			</div><!--/row-->

			
			<!-- end: Content -->
									@endsection
