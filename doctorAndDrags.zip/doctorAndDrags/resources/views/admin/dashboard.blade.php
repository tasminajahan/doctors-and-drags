@extends('loginmaster')
@section('content')

			<noscript>
				<div class="alert alert-block span10">
					<h4 class="alert-heading">Warning!</h4>
					<p>You need to have <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a> enabled to use this site.</p>
				</div>
			</noscript>
			
			<!-- start: Content -->
			<div id="content" class="span10" style="height: auto">
			
			
			<ul class="breadcrumb">
				<li>
					<i class="icon-home"></i>
					<a href="index.html">Home</a> 
					<i class="icon-angle-right"></i>
				</li>
				<li><a href="#">Dashboard</a></li>
			</ul>

			<div class="row-fluid">
				
				<div class="span3 statbox purple" onTablet="span6" onDesktop="span3">
					
					<div class="number"><?php echo $doctor_type ?><i class="icon-arrow-up"></i></div>
					<div class="title">Doctor's Type</div>
						
				</div>
				<div class="span3 statbox green" onTablet="span6" onDesktop="span3">
					<div class="number"><?php echo $assistant ?><i class="icon-arrow-up"></i></div>
					<div class="title">Assistant</div>
					
				</div>
				<div class="span3 statbox blue noMargin" onTablet="span6" onDesktop="span3">
					<div class="number"><?php echo $doctor ?><i class="icon-arrow-up"></i></div>
					<div class="title">orders</div>
					
				</div>
				<div class="span3 statbox yellow" onTablet="span6" onDesktop="span3">
					<div class="number"><?php echo $prescription ?><i class="icon-arrow-down"></i></div>
					<div class="title">visits</div>
					
				</div>	
				
			</div>	
			<div class="row-fluid">
				<?php 
				foreach ($doctor_with_image as $docImage) {
					# code...
				
				 ?>
				
				<div class="span4 statbox purple" onTablet="span6" onDesktop="span3">
					<center>
						<h2>
							Dr. <?php echo $docImage->doctor_name ?>
						</h2>
					</center>
					
					<img style="max-width:100%;height:280px" class="img-responsive" src="<?php echo $docImage->img ?>" alt="member-1">
						
				</div>
			<?php } ?>
				
			</div>		

			
				
			
			
       

	</div><!--/.fluid-container-->
			<!-- end: Main Menu -->
			@endsection