@yield('head')

	 @yield('body')
	<!-- footer starts here -->
	@yield('tail')