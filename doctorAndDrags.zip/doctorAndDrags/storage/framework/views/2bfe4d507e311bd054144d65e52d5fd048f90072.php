
<?php $__env->startSection('footer'); ?>
<footer>

		<p>
			<span style="text-align:left;float:left">&copy; 2013 <a href="http://themifycloud.com/downloads/janux-free-responsive-admin-dashboard-template/" alt="Bootstrap_Metro_Dashboard">Job Finder Admin Dashboard</a></span>
			
		</p>

	</footer>
	
	<!-- start: JavaScript-->

		<script src="<?php echo e(URL::to('public/Admin/js/jquery-1.9.1.min.js')); ?>"></script>
	<script src="<?php echo e(URL::to('public/Admin/js/jquery-migrate-1.0.0.min.js')); ?>"></script>
	
		<script src="<?php echo e(URL::to('public/Admin/js/jquery-ui-1.10.0.custom.min.js')); ?>"></script>
	
		<script src="<?php echo e(URL::to('public/Admin/js/jquery.ui.touch-punch.js')); ?>"></script>
	
		<script src="<?php echo e(URL::to('public/Admin/js/modernizr.js')); ?>"></script>
	
		<script src="<?php echo e(URL::to('public/Admin/js/bootstrap.min.js')); ?>"></script>
	
		<script src="<?php echo e(URL::to('public/Admin/js/jquery.cookie.js')); ?>"></script>
	
		<script src="<?php echo e(URL::to('public/Admin/js/fullcalendar.min.js')); ?>"></script>
	
		<script src="<?php echo e(URL::to('public/Admin/js/jquery.dataTables.min.js')); ?>"></script>

		<script src="<?php echo e(URL::to('public/Admin/js/excanvas.js')); ?>"></script>
	<script src="<?php echo e(URL::to('public/Admin/js/jquery.flot.js')); ?>"></script>
	<script src="<?php echo e(URL::to('public/Admin/js/jquery.flot.pie.js')); ?>"></script>
	<script src="<?php echo e(URL::to('public/Admin/js/jquery.flot.stack.js')); ?>"></script>
	<script src="public/Admin/js/jquery.flot.resize.min.js"></script>
	
		<script src="<?php echo e(URL::to('public/Admin/js/jquery.chosen.min.js')); ?>"></script>
	
		<script src="<?php echo e(URL::to('public/Admin/js/jquery.uniform.min.js')); ?>"></script>
		
		<script src="<?php echo e(URL::to('public/Admin/js/jquery.cleditor.min.js')); ?>"></script>
	
		<script src="<?php echo e(URL::to('public/Admin/js/jquery.noty.js')); ?>"></script>
	
		<script src="<?php echo e(URL::to('public/Admin/js/jquery.elfinder.min.js')); ?>"></script>
	
		<script src="<?php echo e(URL::to('public/Admin/js/jquery.elfinder.min.js')); ?>"></script>
	
		<script src="<?php echo e(URL::to('public/Admin/js/jquery.iphone.toggle.js')); ?>"></script>
	
		<script src="<?php echo e(URL::to('public/Admin/js/jquery.uploadify-3.1.min.js')); ?>"></script>
	
		<script src="<?php echo e(URL::to('public/Admin/js/jquery.gritter.min.js')); ?>"></script>
	
		<script src="<?php echo e(URL::to('public/Admin/js/jquery.imagesloaded.js')); ?>"></script>
	
		<script src="<?php echo e(URL::to('public/Admin/js/jquery.imagesloaded.js')); ?>"></script>
	
		<script src="<?php echo e(URL::to('public/Admin/js/jquery.imagesloaded.js')); ?>"></script>
	
		<script src="<?php echo e(URL::to('public/Admin/js/jquery.sparkline.min.js')); ?>"></script>
	
		<script src="<?php echo e(URL::to('public/Admin/js/counter.js')); ?>"></script>
	
		<script src="<?php echo e(URL::to('public/Admin/js/retina.js')); ?>"></script>

		<script src="<?php echo e(URL::to('public/Admin/js/custom.js')); ?>"></script>
	<!-- end: JavaScript-->
	
</body>
</html>

			<?php $__env->stopSection(); ?>
<?php echo $__env->make('loginmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\doctorAndDrags\resources\views/admin/footer.blade.php ENDPATH**/ ?>