
<?php $__env->startSection('content'); ?>
<div id="content" class="span10">
			
			
			<ul class="breadcrumb">
				<li>
					<i class="icon-home"></i>
					<a href="">Write</a>
					<i class="icon-angle-right"></i> 
				</li>
				<li>
					<i class="icon-edit"></i>
					<a href="#">Prescription</a>
				</li>
			</ul>
			
			<div class="row-fluid sortable">
				<div class="box span12">
					<div class="box-header" data-original-title>
						<h2><i class="halflings-icon white edit"></i><span class="break"></span>Prescription </h2>
						<div class="box-icon">
							<a href="#" class="btn-setting"><i class="halflings-icon white wrench"></i></a>
							<a href="#" class="btn-minimize"><i class="halflings-icon white chevron-up"></i></a>
							<a href="#" class="btn-close"><i class="halflings-icon white remove"></i></a>
						</div>
					</div>
					<div class="box-content">
						<h3 style="color:green">
                    <?php
                     $message=Session::get('message');
                     if($message){
                         echo $message;
                         Session::put('message',null);
                     }
                    ?>
                    </h3>
						<?php echo Form::open(['url' => '/save_Prescription','method' => 'post','enctype'=>'multipart/form-data']); ?>

						  <fieldset>

						 
							
							
							<div class="control-group">
							  <label class="control-label" for="date01">Patient Name</label>
							  <div class="controls">
								<input type="text" class="span6 typeahead" name="patient_name" style="background-color: #578EBE;color:white">
							  </div>
							</div>
							<div class="control-group">
							  <label class="control-label" for="date01">Patient Age</label>
							  <div class="controls">
								<input type="number" class="span6 typeahead" name="patient_age" style="background-color: #578EBE;color:white">
							  </div>
							</div>
							<div class="control-group">
							  <label class="control-label" for="date01">Patient Gender</label>
							  <div class="controls">
								<input type="text" class="span6 typeahead" name="patient_gender" style="background-color: #578EBE;color:white">
							  </div>
							</div>
							
							<div class="control-group hidden-phone">
							  <label class="control-label" for="textarea2">Prescription</label>
							  <div class="controls">
								<textarea  rows="8"  name="prescription body" style="background-color: #578EBE;color:white;width: 500px" ></textarea>
							  </div>
							</div>
							
							
							

							         
							
							<div class="form-actions">
							  <button type="submit" class="btn btn-primary">Post</button>
							</div>
						  </fieldset>
						<?php echo Form::close(); ?>


					</div>
				</div><!--/span-->

			</div><!--/row-->
						<?php $__env->stopSection(); ?>

<?php echo $__env->make('loginmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\New folder\htdocs\doctorAndDrags\resources\views/admin/viewallUser.blade.php ENDPATH**/ ?>