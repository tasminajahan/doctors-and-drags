	
<?php $__env->startSection('content'); ?>	
			<noscript>
				<div class="alert alert-block span10">
					<h4 class="alert-heading">Warning!</h4>
					<p>You need to have <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a> enabled to use this site.</p>
				</div>
			</noscript>
			
			<!-- start: Content -->
			<div id="content" class="span10">
	
			
			<ul class="breadcrumb">
				<li>
					<i class="icon-home"></i>
					<a href="index.html">All</a> 
					<i class="icon-angle-right"></i>
				</li>
				<li><a href="#">Doctor Type</a></li>
			</ul>

			<div class="row-fluid sortable" style="height: 1000px">		
				<div class="box span12">
					<div class="box-header" data-original-title>
						<h2><i class="halflings-icon white user"></i><span class="break"></span>Types</h2>
						<div class="box-icon">
							<a href="#" class="btn-setting"><i class="halflings-icon white wrench"></i></a>
							<a href="#" class="btn-minimize"><i class="halflings-icon white chevron-up"></i></a>
							<a href="#" class="btn-close"><i class="halflings-icon white remove"></i></a>
						</div>
					</div>
					<div class="box-content">
						<table class="table table-striped table-bordered bootstrap-datatable datatable">
						  <thead>
							  <tr>
								  <th>No</th>
								  <th>Doctor's Type</th>
								  <th>Doctor's Name</th>
								  <th>Picture</th>
								 
								  <th>Actions</th>
							  </tr>
						  </thead>   
						  <tbody>
						  	<?php
						  	foreach ($all_doctor as $allDoctor) {
						  	 	# code...
						  	 
						  	 ?>
							<tr>
								<td><?php echo $allDoctor->doctor_id  ?></td>
								<td>
									<?php
									foreach ($allDoctorType as $type) {
										# code...
									if ($type->type_id==$allDoctor->doctor_type) {
										# code...
									
									 echo $type->type_name; 
                                          }
                                      }
									 ?></td>
								<td><?php echo $allDoctor->doctor_name	 ?></td>
								<td class="center"><img  src="<?php echo e(asset($allDoctor->img)); ?>" / style="height: 80px;width: 130px"></td>
								
								
								<td class="center">
									
									<a class="btn btn-info" href="<?php echo e(URL::to('/editDoctor',$allDoctor->doctor_id )); ?>" >
										<i class="halflings-icon white edit"></i>  
									</a>
									<a class="btn btn-danger" href="<?php echo e(URL::to('/deleteDoctor',$allDoctor->doctor_id )); ?>" onclick="return confirm('Are you sure?')">
										<i class="halflings-icon white trash"></i> 
									</a>
								</td>
							</tr>
						<?php } ?>
							
							
							
							
							
						  </tbody>
					  </table>            
					</div>
				</div><!--/span-->
			
			</div><!--/row-->

			
			<!-- end: Content -->
									<?php $__env->stopSection(); ?>

<?php echo $__env->make('loginmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\doctorAndDrags\resources\views/admin/viewAllDoctor.blade.php ENDPATH**/ ?>