	
<?php $__env->startSection('content'); ?>	
			<noscript>
				<div class="alert alert-block span10">
					<h4 class="alert-heading">Warning!</h4>
					<p>You need to have <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a> enabled to use this site.</p>
				</div>
			</noscript>
			
			<!-- start: Content -->
			<div id="content" class="span10" style="height:auto;">
	
			
			<ul class="breadcrumb">
				<li>
					<i class="icon-home"></i>
					<a href="index.html">Home</a> 
					<i class="icon-angle-right"></i>
				</li>
				<li><a href="#">Job</a></li>
			</ul>

			<div class="row-fluid sortable">		
				<div class="box span12">
					<div class="box-header" data-original-title>
						<h2><i class="halflings-icon white user"></i><span class="break"></span>Job List</h2>
						<div class="box-icon">
							<a href="#" class="btn-setting"><i class="halflings-icon white wrench"></i></a>
							<a href="#" class="btn-minimize"><i class="halflings-icon white chevron-up"></i></a>
							<a href="#" class="btn-close"><i class="halflings-icon white remove"></i></a>
						</div>
					</div>
					<div class="box-content">
						<table class="table table-striped table-bordered bootstrap-datatable datatable">
						  <thead>
						  							  
							  <tr>
								  <th>No</th>
								  <th>Sender Name</th>
								  <th>Email</th>
								  <th>Message Subject</th>
								  <th>Message</th>
								  
								 
								  <th>Actions</th>
							  </tr>
						  </thead>   
						  <tbody>
						  		<?php
        foreach($all_news_info as $v_info){
    ?>
							<tr>
								<td class="center"><?php echo $v_info->ms_id ?></td>
								
								
								<td class="center"><?php echo $v_info->messerger_name ?></td>
								<td class="center"><?php echo $v_info->messager_email ?></td>
								<td class="center"><?php echo $v_info->message_subject ?></td>
								<td class="center"><?php echo $v_info->message_body ?></td>
								
								
								<td class="center">
									
									
									<a class="btn btn-danger" href="<?php echo e(URL::to('/delete_message',$v_info->ms_id)); ?>" onclick="return confirm('Are you sure?')">
										<i class="halflings-icon white trash"></i> 
									</a>
								</td>
							</tr>
						<?php } ?>
							
							
							
						  </tbody>
					  </table>            
					</div>
				</div><!--/span-->
			
			</div><!--/row-->

			
			<!-- end: Content -->
									<?php $__env->stopSection(); ?>

<?php echo $__env->make('loginmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\doctorAndDrags\resources\views/admin/viewMessage.blade.php ENDPATH**/ ?>