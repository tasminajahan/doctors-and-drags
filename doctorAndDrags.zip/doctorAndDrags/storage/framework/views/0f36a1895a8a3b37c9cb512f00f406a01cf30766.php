
<?php $__env->startSection('tail'); ?>
	<footer class="footer clearfix">
		<div class="container">
			<div class="row">
				<div class="col-xs-6 footer-para">
					<p>&copy;Mostafizur All right reserved</p>
				</div>
				<div class="col-xs-6 text-right">
					<a href=""><i class="fa fa-facebook"></i></a>
					<a href=""><i class="fa fa-twitter"></i></a>
					<a href=""><i class="fa fa-skype"></i></a>
				</div>
			</div>
		</div>
	</footer>

	<!-- script tags
	============================================================= -->
	<script src="<?php echo e(URL::to('public/js/jquery-2.1.1.js')); ?>"></script>
	<script src="http://maps.google.com/maps/api/js?sensor=true"></script>
	<script src="<?php echo e(URL::to('public/js/gmaps.js')); ?>"></script>
	<script src="<?php echo e(URL::to('public/js/smoothscroll.js')); ?>"></script>
	<script src="<?php echo e(URL::to('public/js/bootstrap.min.js')); ?>"></script>
	<script src="<?php echo e(URL::to('public/js/custom.js')); ?>"></script>
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\doctorAndDrags\resources\views/pages/footer.blade.php ENDPATH**/ ?>