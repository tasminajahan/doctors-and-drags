
<?php $__env->startSection('content'); ?>
<div id="content" class="span10">
			
			
			<ul class="breadcrumb">
				<li>
					<i class="icon-home"></i>
					<a href="">Add</a>
					<i class="icon-angle-right"></i> 
				</li>
				<li>
					<i class="icon-edit"></i>
					<a href="#">Job</a>
				</li>
			</ul>
			
			<div class="row-fluid sortable">
				<div class="box span12">
					<div class="box-header" data-original-title>
						<h2><i class="halflings-icon white edit"></i><span class="break"></span>Job Detail</h2>
						<div class="box-icon">
							<a href="#" class="btn-setting"><i class="halflings-icon white wrench"></i></a>
							<a href="#" class="btn-minimize"><i class="halflings-icon white chevron-up"></i></a>
							<a href="#" class="btn-close"><i class="halflings-icon white remove"></i></a>
						</div>
					</div>
					<div class="box-content">
						<h3 style="color:green">
                    <?php
                     $message=Session::get('message');
                     if($message){
                         echo $message;
                         Session::put('message',null);
                     }
                    ?>
                    </h3>
						<?php echo Form::open(['url' => '/update_schedule','method' => 'post','enctype'=>'multipart/form-data']); ?>

						  <fieldset>

						 
							
							
							<div class="control-group">
							  <label class="control-label" for="date01">Moorning</label>
							  <div class="controls">
								<input type="text" class="span6 typeahead" name="moorning" style="background-color: #578EBE;color:white" value="<?php echo $allSchedule->moorning ?>">
								<input type="hidden" class="span6 typeahead" name="id" style="background-color: #578EBE;color:white" value="<?php echo $allSchedule->id ?>">
							  </div>
							</div>
							<div class="control-group">
							  <label class="control-label" for="date01">Place </label>
							  <div class="controls">
								<input type="text" class="span6 typeahead" name="moorning_place" style="background-color: #578EBE;color:white" value="<?php echo $allSchedule->moorning_place ?>">
							  </div>
							</div>
							<div class="control-group">
							  <label class="control-label" for="date01">After Noon Time</label>
							  <div class="controls">
								<input type="text" class="span6 typeahead" name="afternoon" style="background-color: #578EBE;color:white" value="<?php echo $allSchedule->afternoon ?>">
							  </div>
							</div>
							<div class="control-group">
							  <label class="control-label" for="date01">Place </label>
							  <div class="controls">
								<input type="text" class="span6 typeahead" name="afternoon_place" style="background-color: #578EBE;color:white" value="<?php echo $allSchedule->afternoon_place ?>">
							  </div>
							</div>
							<div class="control-group">
							  <label class="control-label" for="date01">Evening Time</label>
							  <div class="controls">
								<input type="text" class="span6 typeahead" name="Evening" style="background-color: #578EBE;color:white" value="<?php echo $allSchedule->Evening ?>">
							  </div>
							</div>
							<div class="control-group">
							  <label class="control-label" for="date01">Place </label>
							  <div class="controls">
								<input type="text" class="span6 typeahead" name="evening_plcae" style="background-color: #578EBE;color:white" value="<?php echo $allSchedule->evening_plcae ?>">
							  </div>
							</div>
							<div class="control-group">
							  <label class="control-label" for="date01">Night Time</label>
							  <div class="controls">
								<input type="text" class="span6 typeahead" name="night" style="background-color: #578EBE;color:white" value="<?php echo $allSchedule->night ?>">
							  </div>
							</div>
							<div class="control-group">
							  <label class="control-label" for="date01">Place </label>
							  <div class="controls">
								<input type="text" class="span6 typeahead" name="night_plcae" style="background-color: #578EBE;color:white" value="<?php echo $allSchedule->night_plcae ?>">
							  </div>
							</div>
							
							         
							
							<div class="form-actions">
							  <button type="submit" class="btn btn-primary">Update</button>
							</div>
						  </fieldset>
						<?php echo Form::close(); ?>


					</div>
				</div><!--/span-->

			</div><!--/row-->
						<?php $__env->stopSection(); ?>

<?php echo $__env->make('loginmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\New folder\htdocs\doctorAndDrags\resources\views/admin/editSchedule.blade.php ENDPATH**/ ?>