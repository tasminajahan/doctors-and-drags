
<?php $__env->startSection('body'); ?>
<section class="team" id="team">
		<div class="container">
			<div class="row">
				<div class="team-heading text-center" style="margin-top: 15%">
					<h2>our team</h2>
					<h4>Our Doctor List is enrich with Special Personalities</h4>
				</div>
				<?php 
				foreach ($doctor as $do) {
					# code...
				
				 ?>
				 <a href="<?php echo e(URL::to('/showDoctorById',$do->doctor_id )); ?>">
				<div class="col-md-4 single-member col-sm-4">
					<div class="person">
						<img style="max-width:100%;height:280px" class="img-responsive" src="<?php echo $do->img ?>" alt="member-1">
					</div>
					<div class="person-detail">
						<div class="arrow-bottom"></div>
						<h3><?php echo $do->doctor_name ?></h3>
						<p><?php echo $doctor_type->type_name ?> </p>
					</div>
				</div>
				</a>
			<?php } ?>
				
				
				
				
				
			</div>
		</div>
	</section><!-- end of team section -->
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\New folder\htdocs\doctorAndDrags\resources\views/pages/DoctorByType.blade.php ENDPATH**/ ?>