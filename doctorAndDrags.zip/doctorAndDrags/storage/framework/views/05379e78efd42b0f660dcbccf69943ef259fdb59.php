
<?php $__env->startSection('content'); ?>
<div id="content" class="span10">
			
			
			<ul class="breadcrumb">
				<li>
					<i class="icon-home"></i>
					<a href="">Edit</a>
					<i class="icon-angle-right"></i> 
				</li>
				<li>
					<i class="icon-edit"></i>
					<a href="#">Type</a>
				</li>
			</ul>
			
			<div class="row-fluid sortable" style="height: 100vh">
				<div class="box span12">
					<div class="box-header" data-original-title>
						<h2><i class="halflings-icon white edit"></i><span class="break"></span>Doctor Type</h2>

						<div class="box-icon">
							<a href="#" class="btn-setting"><i class="halflings-icon white wrench"></i></a>
							<a href="#" class="btn-minimize"><i class="halflings-icon white chevron-up"></i></a>
							<a href="#" class="btn-close"><i class="halflings-icon white remove"></i></a>
						</div>
					</div>
					<div class="box-content">
						 <?php echo Form::open(['url' => '/update_doctor','method' => 'post','enctype'=>'multipart/form-data']); ?>

						  <fieldset>
							
							
							
							<div class="control-group">
							  <label class="control-label" for="date01">Doctor Type</label>
							  <h3 style="color:green">
                    <?php
                     $message=Session::get('message');
                     if($message){
                         echo $message;
                         Session::put('message',null);
                     }
                    ?>
                    </h3>
							 <div class="controls">
								<select name="doctor_type">
									<option value="<?php echo $doctor->doctor_type; ?>">
                                   <?php 
                                      foreach($doctor_type as $v_category){
                                      	# code...
                                     if ($doctor->doctor_type==$v_category->type_id) {
                                     	# code...
                                     
                                    ?>

										<?php echo $v_category->type_name ?></option>
									<?php } 
								} ?>
								<?php
								 foreach($doctor_type as $v_category){  
								 ?>
								 
							<option value="<?php echo $v_category->type_id ?>"><?php echo $v_category->type_name ?></option>
							
                                 <?php } ?>
							</select>
							  </div>
							  <div class="controls">
							  	<input type="text" class="span6 typeahead" name="doctor_name" value="<?php echo $doctor->doctor_name ?>">
							  	<input type="hidden" class="span6 typeahead" name="doctor_id" value="<?php echo $doctor->doctor_id ?>">
							</div>
							<div class="control-group">
							  <label class="control-label" for="fileInput">Image</label>
							  <div class="controls">
								<input class="input-file uniform_on" id="fileInput" type="file" name="img" value="">
								<input type="hidden" name="prev_image" value="<?php echo $doctor->img ?>">
							  </div>
							</div>  

							         
							
							<div class="form-actions">
							  <button type="submit" class="btn btn-primary">update</button>
							</div>
						  </fieldset>
						 <?php echo Form::close(); ?>


					</div>
				</div><!--/span-->

			</div><!--/row-->
						<?php $__env->stopSection(); ?>

<?php echo $__env->make('loginmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\doctorAndDrags\resources\views/admin/editDoctor.blade.php ENDPATH**/ ?>