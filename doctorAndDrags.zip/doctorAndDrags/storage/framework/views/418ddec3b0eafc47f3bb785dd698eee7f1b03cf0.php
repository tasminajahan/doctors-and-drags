<?php echo $__env->yieldContent('head'); ?>

	 <?php echo $__env->yieldContent('body'); ?>
	<!-- footer starts here -->
	<?php echo $__env->yieldContent('tail'); ?><?php /**PATH /opt/lampp/htdocs/doctorAndDrags/resources/views/master.blade.php ENDPATH**/ ?>