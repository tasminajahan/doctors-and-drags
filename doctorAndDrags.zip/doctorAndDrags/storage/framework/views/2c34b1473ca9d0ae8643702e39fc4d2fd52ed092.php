	
<?php $__env->startSection('content'); ?>	
			<noscript>
				<div class="alert alert-block span10">
					<h4 class="alert-heading">Warning!</h4>
					<p>You need to have <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a> enabled to use this site.</p>
				</div>
			</noscript>
			
			<!-- start: Content -->
			<div id="content" class="span10" style="height: 100vh">
	
			
			<ul class="breadcrumb">
				<li>
					<i class="icon-home"></i>
					<a href="index.html">Home</a> 
					<i class="icon-angle-right"></i>
				</li>
				<li><a href="#">Tables</a></li>
			</ul>

			<div class="row-fluid sortable" style="height: 100vh">		
				<div class="box span12">
					<div class="box-header" data-original-title>
						<h2><i class="halflings-icon white user"></i><span class="break"></span>Members</h2>
						<div class="box-icon">
							<a href="#" class="btn-setting"><i class="halflings-icon white wrench"></i></a>
							<a href="#" class="btn-minimize"><i class="halflings-icon white chevron-up"></i></a>
							<a href="#" class="btn-close"><i class="halflings-icon white remove"></i></a>
						</div>
					</div>
					<div class="box-content">
						<table class="table table-striped table-bordered bootstrap-datatable datatable">
						  <thead>
							  <tr>
								  <th>Patient ID</th>
								  <th>Name</th>
								 
								  <th>Age</th>
								  <th>Gender</th>
								  <th>Created At</th>
								  <th>Payment Status</th>
								
								 
								   <th>Download</th>
								
							  </tr>
						  </thead>   
						  <tbody>
						  	<?php
						  	foreach ($allAppointment as $assis) {
						  	 	# code...
						  	 
						  	 ?>
							<tr>
								
								<td class="center"><?php echo $assis->patient_id  ?></td>
								<td class="center"><?php echo $assis->patient_name ?></td>
								<td class="center"><?php echo $assis->patient_age ?></td>
								<td class="center"><?php echo $assis->patient_gender ?></td>
								<td class="center"><?php echo $assis->created_at ?></td>
								<?php 
                                    if ($assis->payment_status==0) {
                                    	# code...
                                   
								 ?>
								<td class="center"><a href="<?php echo e(URL::to('/makePaymentOk',$assis->patient_id)); ?>"><button type="button" class="btn btn-warning">Payment Pending</button></a></td>
								<?php } else{ ?>
									<td class="center"><a href=""><button type="button" class="btn btn-primary">Payment Ok</button></a></td>
								<?php } ?>
								
								
								 <?php 
								  if ($assis->payment_status==1) {
								  	# code...
								  
								   ?>
								<td class="center"><a href="<?php echo e(URL::to('/dawonloadPrescription',$assis->patient_id)); ?>"><button type="button" class="btn btn-warning">Dawonload Pdf</button></a></td>
							<?php } ?>
							</tr>
							<?php } ?>
						  </tbody>
					  </table>            
					</div>
				</div><!--/span-->
			
			</div><!--/row-->

			
			<!-- end: Content -->
									<?php $__env->stopSection(); ?>

<?php echo $__env->make('loginmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\doctorAndDrags\resources\views/admin/allAppointment.blade.php ENDPATH**/ ?>