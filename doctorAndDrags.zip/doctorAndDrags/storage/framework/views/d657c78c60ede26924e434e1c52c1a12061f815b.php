
<?php $__env->startSection('content'); ?>
<div id="content" class="span10">
			
			
			<ul class="breadcrumb">
				<li>
					<i class="icon-home"></i>
					<a href="">Edit</a>
					<i class="icon-angle-right"></i> 
				</li>
				<li>
					<i class="icon-edit"></i>
					<a href="#">Type</a>
				</li>
			</ul>
			
			<div class="row-fluid sortable" style="height: 100vh">
				<div class="box span12">
					<div class="box-header" data-original-title>
						<h2><i class="halflings-icon white edit"></i><span class="break"></span>Doctor Type</h2>

						<div class="box-icon">
							<a href="#" class="btn-setting"><i class="halflings-icon white wrench"></i></a>
							<a href="#" class="btn-minimize"><i class="halflings-icon white chevron-up"></i></a>
							<a href="#" class="btn-close"><i class="halflings-icon white remove"></i></a>
						</div>
					</div>
					<div class="box-content">
						 <?php echo Form::open(['url' => '/update_assistant','method' => 'post','enctype'=>'multipart/form-data']); ?>

						  <fieldset>
							
							
							
							<div class="control-group">
							  <label class="control-label" for="date01">Doctor Type</label>
							  <h3 style="color:green">
                    <?php
                     $message=Session::get('message');
                     if($message){
                         echo $message;
                         Session::put('message',null);
                     }
                    ?>
                    </h3>
							
							  <div class="controls">
							  	<label>Assistant Name</label>
							  	<input type="text" class="span6 typeahead" name="assistant_name" value="<?php echo $assistant->assistant_name ?>">
							  	<input type="hidden" name="assistant_id" value="<?php echo $assistant->assistant_id ?>">
							  	
							</div>

							         
							
							<div class="form-actions">
							  <button type="submit" class="btn btn-primary">update</button>
							</div>
						  </fieldset>
						 <?php echo Form::close(); ?>


					</div>
				</div><!--/span-->

			</div><!--/row-->
						<?php $__env->stopSection(); ?>

<?php echo $__env->make('loginmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\New folder\htdocs\doctorAndDrags\resources\views/admin/editAssistant.blade.php ENDPATH**/ ?>