	
<?php $__env->startSection('content'); ?>	
			<noscript>
				<div class="alert alert-block span10">
					<h4 class="alert-heading">Warning!</h4>
					<p>You need to have <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a> enabled to use this site.</p>
				</div>
			</noscript>
			
			<!-- start: Content -->
			<div id="content" class="span10" style="height:1000px;">
	
			
			<ul class="breadcrumb">
				<li>
					<i class="icon-home"></i>
					<a href="index.html">Home</a> 
					<i class="icon-angle-right"></i>
				</li>
				<li><a href="#">Job</a></li>
			</ul>

			<div class="row-fluid sortable">		
				<div class="box span12">
					<div class="box-header" data-original-title>
						<h2><i class="halflings-icon white user"></i><span class="break"></span>Job List</h2>
						<div class="box-icon">
							<a href="#" class="btn-setting"><i class="halflings-icon white wrench"></i></a>
							<a href="#" class="btn-minimize"><i class="halflings-icon white chevron-up"></i></a>
							<a href="#" class="btn-close"><i class="halflings-icon white remove"></i></a>
						</div>
					</div>
					<div class="box-content">
						<table class="table table-striped table-bordered bootstrap-datatable datatable">
						  <thead>
						  							  
							  <tr>
								  <th>Ticker No</th>
								  <th>Patient Name</th>
								  <th>Doctor Name</th>
								  <th>Time</th>
								  
								 
								  <th>Actions</th>
							  </tr>
						  </thead>   
						  <tbody>
						  		<?php
        foreach($all_news_info as $v_info){
    ?>
							<tr>
								<td class="center"><?php echo $v_info->ticket_id ?></td>
								
								
								<td class="center"><?php echo $v_info->Patient_name ?></td>
								<td class="center"><?php echo $v_info->doctor_name ?></td>
								<?php 
                                if ($v_info->time==1) {
                                	# code...
                               
								 ?>
								<td class="center">Moorning</td>
							<?php } elseif ($v_info->time==2) {
								# code...
							 ?>
							 <td class="center">AfterNoon</td>
							<?php } elseif ($v_info->time==3) {
								# code...
							 ?>
							 <td class="center">Evening</td>
								<?php } else{ ?>
									<td class="center">Night</td>
								<?php } ?>
								
								<td class="center">
									
									
									<a class="btn btn-danger" href="<?php echo e(URL::to('/delete_message',$v_info->ticket_id)); ?>" onclick="return confirm('Are you sure?')">
										<i class="halflings-icon white trash"></i> 
									</a>
								</td>
							</tr>
						<?php } ?>
							
							
							
						  </tbody>
					  </table>            
					</div>
				</div><!--/span-->
			
			</div><!--/row-->

			
			<!-- end: Content -->
									<?php $__env->stopSection(); ?>

<?php echo $__env->make('loginmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\doctorAndDrags\resources\views/admin/viewAllticket.blade.php ENDPATH**/ ?>